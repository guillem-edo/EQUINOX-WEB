# EQUINOX - Equipos Inoxidables S.L.

Este repositorio contiene el código fuente del sitio web de EQUINOX, una empresa especializada en calderería industrial con más de 30 años de experiencia.

## Estructura del Sitio

- **index.html**: Página principal
- **empresa.html**: Información sobre la empresa
- **productos-servicios.html**: Catálogo de productos y servicios
- **materiales.html**: Información sobre materiales utilizados
- **acabados.html**: Información sobre acabados disponibles
- **calidad.html**: Información sobre estándares de calidad
- **sectores.html**: Sectores industriales atendidos
- **contacto.html**: Formulario de contacto e información
- **css/**: Directorio con archivos de estilo
- **js/**: Directorio con archivos JavaScript
- **img/**: Directorio con imágenes

## Tecnologías Utilizadas

- HTML5
- CSS3
- JavaScript
- Bootstrap 5
- Font Awesome

## Desarrollo Local

Para ejecutar el sitio localmente, simplemente abra el archivo index.html en su navegador o utilice un servidor web local.
